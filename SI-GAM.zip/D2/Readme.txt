q_stratrgyA,  对应策略A涉及的技能
q_stratrgyA，对应策略AB涉及的技能
